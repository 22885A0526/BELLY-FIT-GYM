import pandas as pd
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Download NLTK resources (if not already downloaded)
nltk.download('vader_lexicon')
# Load data using pandas
df = pd.read_csv('reviews.csv')  # Assuming 'reviews.csv' contains the text data

# Initialize the sentiment analyzer
sid = SentimentIntensityAnalyzer()
def analyze_sentiment(text):
    sentiment_scores = sid.polarity_scores(text)
    
    if sentiment_scores['compound'] >= 0.05:
        return 'positive'
    elif sentiment_scores['compound'] <= -0.05:
        return 'negative'
    else:
        return 'neutral'  # Adjust this threshold as per your needs
df['sentiment'] = df['text'].apply(analyze_sentiment)

# Display the results
print(df[['text', 'sentiment']])
